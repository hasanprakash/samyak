const Admin = () => {
    return (
        <div className="admin__container">
            <h1>Admin</h1>
        </div>
    )
}

export default Admin;