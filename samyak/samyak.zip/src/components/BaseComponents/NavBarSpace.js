const NavBarSpace = () => {
    return (
        <div>
            <div className='navbar__behindblock bg-black'></div>
        </div>
    );
}

export default NavBarSpace;