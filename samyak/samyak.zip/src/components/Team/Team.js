import HomePoster from "../Home/HomePoster";

const Team = () => {
    return (
        <div>
            <HomePoster />
        </div>
    )
}

export default Team;