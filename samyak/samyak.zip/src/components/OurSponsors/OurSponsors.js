import HomePoster from "../Home/HomePoster";

const OurSponsors = () => {
    return (
        <div>
            <HomePoster />
        </div>
    )
}

export default OurSponsors;